var classhw10__menu_1_1_main_widget =
[
    [ "__init__", "classhw10__menu_1_1_main_widget.html#a4949f94dc5c1ba949d498b8face9f090", null ],
    [ "btnClicked", "classhw10__menu_1_1_main_widget.html#a86aea05b90af22e9b65efb34d1e24b44", null ],
    [ "closeEvent", "classhw10__menu_1_1_main_widget.html#a34c09ff0c536a5ae93f24b32c018d820", null ],
    [ "initUI", "classhw10__menu_1_1_main_widget.html#a215dca7d2b793104c826fec0b2ef5afc", null ],
    [ "instruction", "classhw10__menu_1_1_main_widget.html#acfe8c104cdf2644f98204d87935dbbdf", null ],
    [ "nextPage", "classhw10__menu_1_1_main_widget.html#a1653c07a85353b180655f03a6add1789", null ],
    [ "choice", "classhw10__menu_1_1_main_widget.html#a6f36cc00f05541bcf46c3206ce4d7f4e", null ],
    [ "widget2", "classhw10__menu_1_1_main_widget.html#aa4c7d75d3ed1ef033edd18e66e8ed60a", null ],
    [ "widget3", "classhw10__menu_1_1_main_widget.html#af63a5e2e4a00819bbc5d9d275c61ac96", null ]
];