var namespaces =
[
    [ "hw10_menu", "namespacehw10__menu.html", null ],
    [ "montage_dir", "namespacemontage__dir.html", null ],
    [ "montage_manager", "namespacemontage__manager.html", null ],
    [ "my_montage_maker", "namespacemy__montage__maker.html", null ],
    [ "plot_montage_clusters", "namespaceplot__montage__clusters.html", null ],
    [ "plot_montages_sample", "namespaceplot__montages__sample.html", null ]
];