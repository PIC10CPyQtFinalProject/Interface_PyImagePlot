var annotated_dup =
[
    [ "hw10_menu", "namespacehw10__menu.html", "namespacehw10__menu" ],
    [ "montage_manager", "namespacemontage__manager.html", "namespacemontage__manager" ]
];