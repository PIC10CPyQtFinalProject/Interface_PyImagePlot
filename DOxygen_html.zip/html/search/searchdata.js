var indexSectionsWithContent =
{
  0: "_bcdfghimnopstw",
  1: "ms",
  2: "hmp",
  3: "hmp",
  4: "_bcgimns",
  5: "cdfimnopstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables"
};

