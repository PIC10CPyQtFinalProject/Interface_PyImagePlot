var searchData=
[
  ['margins',['margins',['../namespacemontage__dir.html#a9057ec7a9b638fbcfa9a1c602859792f',1,'montage_dir.margins()'],['../namespacemy__montage__maker.html#a59891868347527fd36a00304b14384df',1,'my_montage_maker.margins()'],['../namespaceplot__montage__clusters.html#a3774d28f87522de419d00969c6341dd5',1,'plot_montage_clusters.margins()'],['../namespaceplot__montages__sample.html#a810250f6806f56864827bc6e1dc98733',1,'plot_montages_sample.margins()']]],
  ['montage',['montage',['../classhw10__menu_1_1_sub_widget.html#a2185ac2b526c89ee89a2d51386e9ac26',1,'hw10_menu::SubWidget']]],
  ['montage_5ffilename',['montage_filename',['../namespacemontage__dir.html#a6b23955fc05bf3568741b3fb9fdf168f',1,'montage_dir']]],
  ['montage_5fpath',['montage_path',['../namespaceplot__montages__sample.html#a7f0c9132bcabb6c3e833d66d7371a0c2',1,'plot_montages_sample']]]
];
