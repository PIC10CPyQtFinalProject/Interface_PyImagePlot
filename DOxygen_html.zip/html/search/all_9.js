var searchData=
[
  ['nc_5fr',['nc_r',['../namespacemontage__dir.html#a2806977dd121cce1d5db9720784b4eae',1,'montage_dir.nc_r()'],['../namespaceplot__montage__clusters.html#a42b545db3f3dc63ccee9c8685a0baecd',1,'plot_montage_clusters.nc_r()'],['../namespaceplot__montages__sample.html#a970ba1328d22158ba5a62f94c5b962d5',1,'plot_montages_sample.nc_r()']]],
  ['ncols',['ncols',['../namespacemontage__dir.html#aaff180b8f442efb63d0ddea5f38a03d3',1,'montage_dir.ncols()'],['../namespaceplot__montage__clusters.html#adaf556239d0fd3fb8a5929438bfe4a73',1,'plot_montage_clusters.ncols()'],['../namespaceplot__montages__sample.html#a30fb3b96a28930800b272759c7d5f251',1,'plot_montages_sample.ncols()']]],
  ['ncr',['ncr',['../namespacemy__montage__maker.html#a5b3caf2b1a99ebaeec6695943a8f7a09',1,'my_montage_maker']]],
  ['nextpage',['nextPage',['../classhw10__menu_1_1_main_widget.html#a1653c07a85353b180655f03a6add1789',1,'hw10_menu::MainWidget']]],
  ['nrows',['nrows',['../namespacemontage__dir.html#ab552c2949bc41941024263c4e94ed18b',1,'montage_dir.nrows()'],['../namespaceplot__montage__clusters.html#a2ebb3b62cd58f14cd27ad4517dde0e35',1,'plot_montage_clusters.nrows()'],['../namespaceplot__montages__sample.html#aecffa95a47d7b78acef3f2ce2b8445df',1,'plot_montages_sample.nrows()']]]
];
