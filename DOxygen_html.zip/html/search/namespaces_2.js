var searchData=
[
  ['plot_5fmontage_5fclusters',['plot_montage_clusters',['../namespaceplot__montage__clusters.html',1,'']]],
  ['plot_5fmontages_5fsample',['plot_montages_sample',['../namespaceplot__montages__sample.html',1,'']]]
];
