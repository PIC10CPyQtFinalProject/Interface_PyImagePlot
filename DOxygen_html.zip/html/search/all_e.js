var searchData=
[
  ['widget2',['widget2',['../classhw10__menu_1_1_main_widget.html#aa4c7d75d3ed1ef033edd18e66e8ed60a',1,'hw10_menu::MainWidget']]],
  ['widget3',['widget3',['../classhw10__menu_1_1_main_widget.html#af63a5e2e4a00819bbc5d9d275c61ac96',1,'hw10_menu::MainWidget']]]
];
