var searchData=
[
  ['btnclicked',['btnClicked',['../classhw10__menu_1_1_main_widget.html#a86aea05b90af22e9b65efb34d1e24b44',1,'hw10_menu::MainWidget']]]
];
