var searchData=
[
  ['nextpage',['nextPage',['../classhw10__menu_1_1_main_widget.html#a1653c07a85353b180655f03a6add1789',1,'hw10_menu::MainWidget']]]
];
