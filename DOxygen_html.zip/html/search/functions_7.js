var searchData=
[
  ['spath',['sPath',['../classhw10__menu_1_1_sub_widget.html#acfe0a1ffc1ca0121543653de54fc9f18',1,'hw10_menu::SubWidget']]]
];
