var searchData=
[
  ['choice',['choice',['../classhw10__menu_1_1_main_widget.html#a6f36cc00f05541bcf46c3206ce4d7f4e',1,'hw10_menu::MainWidget']]],
  ['closed',['closed',['../classhw10__menu_1_1_sub_widget.html#a7d8d3452c99566d01a7cf4d0092b4cf9',1,'hw10_menu.SubWidget.closed()'],['../classhw10__menu_1_1_sub_widget2.html#a52320bc6f114fd6c294028793857c294',1,'hw10_menu.SubWidget2.closed()']]],
  ['cluster_5ffilenames',['cluster_filenames',['../namespaceplot__montage__clusters.html#a1c63f214593c170b8d8c893b5e9b4e80',1,'plot_montage_clusters']]],
  ['csv1',['csv1',['../namespaceplot__montage__clusters.html#a3bfddb223c09948db8ec0f4ad4ff6776',1,'plot_montage_clusters']]]
];
