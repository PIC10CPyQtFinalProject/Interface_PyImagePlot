var searchData=
[
  ['get_5fimmediate_5fsubdirectories',['get_immediate_subdirectories',['../namespaceplot__montages__sample.html#a2c2b8d64009a02a187934d63dbe47eeb',1,'plot_montages_sample']]]
];
