var hw10__menu_8py =
[
    [ "MainWidget", "classhw10__menu_1_1_main_widget.html", "classhw10__menu_1_1_main_widget" ],
    [ "SubWidget", "classhw10__menu_1_1_sub_widget.html", "classhw10__menu_1_1_sub_widget" ],
    [ "SubWidget2", "classhw10__menu_1_1_sub_widget2.html", "classhw10__menu_1_1_sub_widget2" ],
    [ "main", "hw10__menu_8py.html#aae99c04383c3d065f84c7a89f382a8c6", null ]
];