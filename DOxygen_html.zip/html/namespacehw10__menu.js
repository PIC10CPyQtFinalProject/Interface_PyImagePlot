var namespacehw10__menu =
[
    [ "MainWidget", "classhw10__menu_1_1_main_widget.html", "classhw10__menu_1_1_main_widget" ],
    [ "SubWidget", "classhw10__menu_1_1_sub_widget.html", "classhw10__menu_1_1_sub_widget" ],
    [ "SubWidget2", "classhw10__menu_1_1_sub_widget2.html", "classhw10__menu_1_1_sub_widget2" ]
];