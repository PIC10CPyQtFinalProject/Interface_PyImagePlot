var files =
[
    [ "hw10_menu.py", "hw10__menu_8py.html", "hw10__menu_8py" ],
    [ "montage_dir.py", "montage__dir_8py.html", "montage__dir_8py" ],
    [ "montage_manager.py", "montage__manager_8py.html", [
      [ "Montages", "classmontage__manager_1_1_montages.html", "classmontage__manager_1_1_montages" ]
    ] ],
    [ "my_montage_maker.py", "my__montage__maker_8py.html", "my__montage__maker_8py" ],
    [ "plot_montage_clusters.py", "plot__montage__clusters_8py.html", "plot__montage__clusters_8py" ],
    [ "plot_montages_sample.py", "plot__montages__sample_8py.html", "plot__montages__sample_8py" ]
];