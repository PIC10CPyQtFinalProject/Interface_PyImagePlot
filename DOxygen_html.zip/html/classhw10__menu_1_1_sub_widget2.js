var classhw10__menu_1_1_sub_widget2 =
[
    [ "__init__", "classhw10__menu_1_1_sub_widget2.html#a1a38699f14b689dd7f678811b1f2fec7", null ],
    [ "closeEvent", "classhw10__menu_1_1_sub_widget2.html#a3a1a7ea4d7af38e6cdfb23a965e4d12a", null ],
    [ "initUI", "classhw10__menu_1_1_sub_widget2.html#a44e56835e468136546c21e4c71da4fde", null ]
];